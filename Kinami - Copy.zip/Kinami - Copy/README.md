# Kinami
This is a repository where I will be working on my IT Project I. It is a ratings, reviews and rankings system for the nail beauty industry that will provide a platform for customers to have their voices had. Customers will be able to leave reviews and ratings on a company's profile which can then be viewed by other customers and businesses. 
