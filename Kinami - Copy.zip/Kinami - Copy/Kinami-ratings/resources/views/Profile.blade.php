This is the Profile page

<br> @include('Navigationbar')

<h1>Name: {{$Username}}</h1>