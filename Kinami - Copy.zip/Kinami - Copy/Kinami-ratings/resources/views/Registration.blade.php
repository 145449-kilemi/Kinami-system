This is the registration page

