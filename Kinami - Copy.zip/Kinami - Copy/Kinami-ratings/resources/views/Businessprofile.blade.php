This is the Business Profile Page

<br> @include('Navigationbar')