This is the notifications page

<br> @include('Navigationbar')