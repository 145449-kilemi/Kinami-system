This is the Admin Profile 

<br> @include('Navigationbar')

