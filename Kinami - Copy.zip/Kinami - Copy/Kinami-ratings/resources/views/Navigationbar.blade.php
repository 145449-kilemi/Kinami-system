<ul>
  <li><a href="Home">Home</a></li>
  <li><a href="Profile">Profile</a></li>
  <li><a href="Notifications">Notifications</a></li>
  <li><a href="Favourites">Favourites</a></li>
</ul>