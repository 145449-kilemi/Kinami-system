This is the Favourites page

<br> @include('Navigationbar')