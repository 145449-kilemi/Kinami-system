<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Businessprofile extends Controller
{
    //
    public function index(){

        echo "This is from the Controller";
        return view('Businessprofile');
    }
}
