<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Favourites extends Controller
{
    //
    public function index(){

        echo "This is from the Controller";
        return view('Favourites');
    }
}
