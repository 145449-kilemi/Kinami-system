<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Welcome extends Controller
{
    //
    public function index(){

        echo "This is from the Controller";
        return view('welcome');
    }
}
