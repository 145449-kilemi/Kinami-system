This is the registration page

<?php /**PATH C:\xampp\htdocs\Kinami\Kinami-ratings\resources\views/registration.blade.php ENDPATH**/ ?>