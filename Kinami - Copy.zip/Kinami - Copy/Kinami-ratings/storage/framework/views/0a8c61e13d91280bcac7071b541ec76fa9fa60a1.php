This is the login page

<?php /**PATH C:\xampp\htdocs\Kinami\Kinami-ratings\resources\views/Login.blade.php ENDPATH**/ ?>