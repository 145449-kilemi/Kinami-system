<header>
    <h1>welcome</h1> 
    <aside>
    <a href="<?php echo e(url('Registration')); ?>">Registration</a> . <a href="Login">Login</a> <br>
    </aside>
</header><?php /**PATH C:\xampp\htdocs\Kinami\Kinami-ratings\resources\views/Welcome.blade.php ENDPATH**/ ?>