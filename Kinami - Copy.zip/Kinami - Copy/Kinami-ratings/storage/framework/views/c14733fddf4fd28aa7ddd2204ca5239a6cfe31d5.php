This is the Profile page

<br> <?php echo $__env->make('Navigationbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Name: <?php echo e($Username); ?></h1><?php /**PATH C:\xampp\htdocs\Kinami\Kinami-ratings\resources\views/Profile.blade.php ENDPATH**/ ?>