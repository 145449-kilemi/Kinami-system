This is the Favourites page

<br> <?php echo $__env->make('Navigationbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Kinami\Kinami-ratings\resources\views/Favourites.blade.php ENDPATH**/ ?>