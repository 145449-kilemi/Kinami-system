This is the Homepage

<br> <?php echo $__env->make('Navigationbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br> <h1>Hello Kiki</h1><?php /**PATH C:\xampp\htdocs\Kinami\Kinami-ratings\resources\views/Home.blade.php ENDPATH**/ ?>