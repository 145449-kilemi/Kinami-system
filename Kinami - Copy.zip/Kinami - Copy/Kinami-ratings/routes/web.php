<?php

use App\Http\Controllers\Login;
use App\Http\Controllers\Home;
use App\Http\Controllers\Notifications;
use App\Http\Controllers\Admin;
use App\Http\Controllers\Businessprofile;
use App\Http\Controllers\Favourites;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Registration;
use App\Http\Controllers\Welcome;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Route::get('/', function () {
    return view('welcome');
}); */

Route::get('/', [Welcome::class,"index"]);

Route::get('/Welcomepage', function () {
    return view('Welcomepage');
});

/* Route::get('/Registration', function () {
    return view('Registration');
}); */

Route::get('/Registration', [Registration::class,"index"]);

/* Route::get('/Login', function () {
    return view('Login');
});
 */

Route::get('/Login', [Login::class,"index"]);

/* Route::get('/Home/{Username}', function ($Username) {
    $arr['Username'] = $Username;
    //$arr2['Firstname'] = $Firstname;
    return view('Home', $arr);
}); */

/* Route::get('/Home', function () {
    return view('Home');
}); */

Route::get('/Home', [Home::class,"index"]);

/* Route::get('/Profile/{Username}', function ($Username) {
    $arr['Username'] = $Username;
    return view('Profile', $arr);
}); */

/* Route::get('/Profile', function () {
    return view('Profile');
}); */

Route::get('/Profile', [ProfileController::class,"index"]);

/* Route::get('/Businessprofile/{Username}', function ($Username) {
    $arr['Username'] = $Username;
    return view('Businessprofile', $arr);
});
 */

/* Route::get('/Businessprofile', function () {
    return view('Businessprofile');
});
 */
Route::get('/Businessprofile', [Businessprofile::class,"index"]);

/* Route::get('/Admin/{Username}', function ($Username) {
    $arr['Username'] = $Username;
    return view('Admin', $arr);
}); */

/* Route::get('/Admin', function () {
    return view('Admin');
}); */

Route::get('/Admin', [Admin::class,"index"]);

/* Route::get('/Notifications/{Username}', function ($Username) {
    $arr['Username'] = $Username;
    return view('Notifications', $arr);
}); */

/* Route::get('/Notifications', function () {
    return view('Notifications');
}); */

Route::get('/Notifications', [Notifications::class,"index"]);

/* Route::get('/Favourites/{Username}', function ($Username) {
    $arr['Username'] = $Username;
    return view('Favourites', $arr);
}); */

/* Route::get('/Favourites', function () {
    return view('Favourites');
}); */

Route::get('/Favourites', [Favourites::class,"index"]);

Route::get('/LandingPage', function () {
    return view('LandingPage');
});